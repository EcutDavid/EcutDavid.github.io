(function() {
  // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/readyState
  const XHR_DONE = 4;
  const HTTP_STATUS_SUCCESS = 200;
  let XhrObjectCounter = 0;
  const XHR_OBJECT_COUNT_MAXIMUM = 100;

  function generateDefaultXhrObject() {
    return new Promise(resolve => {
      const generateObject = () => {
        if (XhrObjectCounter < XHR_OBJECT_COUNT_MAXIMUM) {
          XhrObjectCounter++;

          const object = new XMLHttpRequest();
          object.responseType = 'json';
          resolve(object);
        } else {
          // Using a random number here to prevent deferred methods being called the same time
          setTimeout(generateObject, Math.random() * 100);
        }
      };
      generateObject();
    });
  }

  function handleXhrOnStateChange(xhrObject, resolve, reject) {
    if(xhrObject.readyState !== XHR_DONE)
      return;

    if (xhrObject.status === HTTP_STATUS_SUCCESS) {
      resolve(xhrObject.response);
    } else {
      reject(xhrObject.response);
    }
    XhrObjectCounter--;

    // Just incase GC is not that smart since tons of xhrObject is created
    xhrObject = null;
  }

  window.ApiHelper = class {
    static createTournament(numberOfTeams, teamsPerMatch) {
      const promise = new Promise((resolve, reject) => {
        generateDefaultXhrObject().then(xhr => {
          xhr.open('POST', 'tournament');
          xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
          xhr.send(`numberOfTeams=${numberOfTeams}&teamsPerMatch=${teamsPerMatch}`);
          xhr.onreadystatechange = () => handleXhrOnStateChange(xhr, resolve, reject);
        });
      });
      return promise;
    }

    static queryTeam(tournamentId, teamId) {
      const promise = new Promise((resolve, reject) => {
        generateDefaultXhrObject().then(xhr => {
          xhr.open('GET', `team?tournamentId=${tournamentId}&teamId=${teamId}`);
          xhr.send();
          xhr.onreadystatechange = () => handleXhrOnStateChange(xhr, resolve, reject);
        });
      });
      return promise;
    }

    static queryMatch(tournamentId, round, match) {
      const promise = new Promise((resolve, reject) => {
        generateDefaultXhrObject().then(xhr => {
          xhr.open('GET', `match?tournamentId=${tournamentId}&round=${round}&match=${match}`);
          xhr.send();
          xhr.onreadystatechange = () => handleXhrOnStateChange(xhr, resolve, reject);
        });
      });
      return promise;
    }

    static queryWinner(tournamentId, teamScores, matchScore) {
      const promise = new Promise((resolve, reject) => {
        generateDefaultXhrObject().then(xhr => {
          const teamScoresQS = teamScores.map(d => `teamScores=${d}`).join('&');
          xhr.open('GET', `winner?tournamentId=${tournamentId}&${teamScoresQS}&matchScore=${matchScore}`);
          xhr.send();
          xhr.onreadystatechange = () => handleXhrOnStateChange(xhr, resolve, reject);
        });
      });
      return promise;
    }
  };
})();
