class DomManager {
  constructor({onStart}) {
    this.dashboard = document.querySelector('.dashboard');
    this.winnerDescription = document.querySelector('.winner-description');
    this.startButton = document.querySelector('#start');
    this.roundIndicatorArea = document.querySelector('.match-indicator-area');
    this.fetchingIndicator = document.querySelector('.loading-description');
    this.errorText = document.querySelector('.error');

    this.startButton.addEventListener('click', () => {
      const numberOfTeams = document.querySelector('#numberOfTeams').value;
      const teamsPerMatch = document.querySelector('#teamsPerMatch').value;
      onStart(numberOfTeams, teamsPerMatch);
    });
  }

  startTournament() {
    this.clearError();
    this.winnerDescription.style.visibility = 'hidden';
    this.dashboard.style.display = 'none';
    this.startButton.disabled = true;
  }

  endTournament(name) {
    this.fetchingIndicator.innerHTML = '';
    document.querySelector('#winner').innerHTML = name;
    this.winnerDescription.style.visibility = 'visible';
    this.startButton.disabled = false;
  }

  initDashBoard(roundCount) {
    this.dashboard.style.display = 'block';
    this.roundIndicatorArea.innerHTML = '';
    const DOM_NODE_COUNT_PER_TASK = 1000;
    // Split the dom rending into tasks, so other tasks will not be blocked
    const renderDom = () => {
      if (roundCount > 0) {
        let roundIndicatorRawHtml = '';
        for (let i = 0; i < Math.min(roundCount, DOM_NODE_COUNT_PER_TASK); i++) {
          roundIndicatorRawHtml += '<span class="match-indicator"></span>';
        }
        this.roundIndicatorArea.innerHTML += roundIndicatorRawHtml;

        roundCount -= DOM_NODE_COUNT_PER_TASK;
        setTimeout(renderDom, 0);
      }
    };
    renderDom();
  }

  updateFetchingIndicator(text) {
    this.fetchingIndicator.innerHTML = text;
  }

  updateMatchs(roundNumber) {
    // nth-child start with index 1
    const dom = document.querySelector(`.match-indicator:nth-child(${roundNumber + 1})`);
    dom.style.backgroundColor = 'skyblue';
  }

  displayError(errMsg) {
    this.errorText.style.display = 'block';
    this.errorText.innerHTML = errMsg;
    this.startButton.disabled = false;
  }

  clearError() {
    this.errorText.style.display = 'none';
  }
}
