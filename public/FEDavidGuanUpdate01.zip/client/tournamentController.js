/* global ApiHelper, RoutineHelper */
class TournamentController {
  constructor(eventHandleDic) {
    const {
      onFetchingData,
      onMatchFetched,
      onTournamentCreated,
      onError,
      onStartTournament,
      onTournamentFinished
    } = eventHandleDic || {};
    // It will pass the number of last round to  this method when invoking
    this.onFetchingData = onFetchingData || (() => {});
    this.onMatchFetched = onMatchFetched || (() => {});
    this.onError = onError || (() => {});
    this.onTournamentCreated = onTournamentCreated || (() => {});
    this.onTournamentFinished = onTournamentFinished || (() => {});
    this.onStartTournament = onStartTournament || (() => {});

    this.teamDictionary = {};
    this.matchUps = [];
    this.tournamentId = undefined;
    this.matchCounter = 0;
  }

  startTournament(numberOfTeams, teamsPerMatch) {
    this.onStartTournament();
    this.createTournament(numberOfTeams, teamsPerMatch)
      .then(this.queryTeamDictionary.bind(this))
      .then(() => this.startNewRound(teamsPerMatch))
      .catch(reason => this.onError(reason));
  }

  createTournament(numberOfTeams, teamsPerMatch) {
    this.onFetchingData('creating teams');
    return ApiHelper.createTournament(numberOfTeams, teamsPerMatch)
        .then(({matchUps, tournamentId}) => {
          // Sort the matchUps for making "match" field in ascending order
          this.matchUps = matchUps.sort((a, b) => a.match > b.match ? 1 : -1);
          this.tournamentId = tournamentId;
          this.matchCounter = 0;
          const roundCount = RoutineHelper.calcMatchCount(numberOfTeams, teamsPerMatch);
          this.onTournamentCreated(roundCount);
        }
    );
  }

  queryTeamDictionary() {
    return new Promise((resolve, reject) => {
      const queryTeamPromises = this.matchUps.reduce((acc, {teamIds}) => {
        return acc.concat(teamIds);
      }, []).map(d =>
        ApiHelper.queryTeam(this.tournamentId, d)
          .then(res => {
            this.onFetchingData(`Fetching team tournament result(team id: ${d})`);
            return res;
          })
      );

      // Only query the data for team once since their score won't change
      Promise.all(queryTeamPromises).then(values => {
        values.forEach(d => this.teamDictionary[d.teamId] = d);
        resolve();
      }).catch(errObj => reject(errObj));
    });
  }

  startNewRound(teamsPerMatch, currentRound = 0, matchList) {
    if (!matchList)
      matchList = this.matchUps.map(d => d.teamIds.sort());

    const queryMatchPromises = matchList.map((_, i) =>
      ApiHelper
        .queryMatch(this.tournamentId, currentRound, i)
        .then(matchResult => {
          this.onFetchingData(`Fetching match result(round ${currentRound} match ${i})`);
          this.onMatchFetched(this.matchCounter);
          this.matchCounter++;
          return matchResult;
        })
    );

    Promise.all(queryMatchPromises)
      .then(values => {
        this.queryWinners(values, teamsPerMatch, currentRound, matchList);
      }).catch(reason => this.onError(reason));
  }

  queryWinners(matchResults, teamsPerMatch, currentRound, matchList) {
    const queryWinnerPromises = matchResults.map((d, i) => {
      const teamScores = matchList[i].map(t => this.teamDictionary[t].score);
      return ApiHelper.queryWinner(this.tournamentId, teamScores, d.score).then(res => {
        this.onFetchingData(`Fetching winner for(round ${currentRound} match ${i})`);
        return res;
      });
    });
    return Promise.all(queryWinnerPromises).then(values => {
      const winnerScoreList = values.map(d => d.score);
      const winnerIdList = RoutineHelper.findMatchWinnerIdList(
        this.teamDictionary,
        winnerScoreList,
        matchList
      );
      const matchCount = winnerIdList.length;
      // One winner === last round
      if (winnerIdList.length === 1) {
        this.onTournamentFinished(this.teamDictionary[winnerIdList[0]].name);
      } else {
        matchList = [];
        for (let i = 0; i < matchCount / teamsPerMatch; i++)
          matchList.push(winnerIdList.splice(0, teamsPerMatch));

        currentRound++;
        this.startNewRound(teamsPerMatch, currentRound, matchList);
      }
    }).catch(reason => this.onError(reason));
  }
}
