#### A git repo for the Canva coding test from David Guan([davidguan.me](http://davidguan.me/))

![](https://s3-ap-southeast-1.amazonaws.com/davidguan/Canva.gif)

The initial README.md has been renamed to OriginalREADME.md

```
npm install
npm start
// or
npm test
```
