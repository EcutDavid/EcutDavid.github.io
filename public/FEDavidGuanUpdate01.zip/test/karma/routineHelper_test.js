/* global expect, RoutineHelper */

// http://chaijs.com/api
// https://mochajs.org
// http://sinonjs.org/docs

describe('RoutineHelper test', function() {
  it('calcRoundCount for 256 teams in total', function() {
    let result = RoutineHelper.calcRoundCount(256, 2);
    expect(result).to.equal(8);
    result = RoutineHelper.calcRoundCount(256, 4);
    expect(result).to.equal(4);
  });
});
