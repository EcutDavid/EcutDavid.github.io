The initial README.md has been renamed to OriginalREADME.md

### Known issue
1. ![](https://cloud.githubusercontent.com/assets/10692276/23413164/da039516-fe12-11e6-9e27-dbfed8c55a75.png)
User has to wait for a long time when the count of team is a big number, better UX and performance tuning TBA.
