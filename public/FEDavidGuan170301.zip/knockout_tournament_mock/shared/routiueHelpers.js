class RoutineHelper {
  static findMatchWinnerIdList(teamDic, winnerScoreList, matchList) {
    return matchList.map((d, i) => {
      const match = matchList[i];
      const winnerScore = winnerScoreList[i];
      return match.find(d => teamDic[d].score === winnerScore);
    });
  }

  // Notice:
  // Thanks to the back-end, the numberOfTeams is the interger pow of teamsPerMatch
  // Need change this part if the feature is no longer supported in back-end
  static calcRoundCount(numberOfTeams, teamsPerMatch) {
    let count = 0;
    while (numberOfTeams > 1) {
      numberOfTeams /= teamsPerMatch;
      count ++;
    }
    return count;
  }
}
