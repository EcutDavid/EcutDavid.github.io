// Notive: the reason for using /* global  */:
//         A sign as there should be no worry that these global object not exist
//         Eaiser for eslint integration in the future.
/* global TournamentController, DomManager */
window.onload = () => {
    const domManager = new DomManager({
      onStart: (numberOfTeams, teamsPerMatch) => {
        controller.startTournament(numberOfTeams, teamsPerMatch);
      }
    });

    const controller = new TournamentController({
      onError: (error) => domManager.displayError(error ? error.message : 'application failed'),
      onRoundChnage: roundNumber => domManager.updateRounds(roundNumber),
      onStartTournament: () => domManager.startTournament(),
      onTournamentCreated: roundCount => domManager.initDashBoard(roundCount),
      onTournamentFinished: teamName => domManager.endTournament(teamName)
    });
};
