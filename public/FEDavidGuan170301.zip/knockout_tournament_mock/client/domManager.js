class DomManager {
  constructor({onStart}) {
    this.dashboard = document.querySelector('.dashboard');
    this.winnerDescription = document.querySelector('.winner-description');
    this.startButton = document.querySelector('#start');
    this.roundIndicatorArea = document.querySelector('.round-indicator-area');
    this.errorText = document.querySelector('.error');

    this.startButton.addEventListener('click', () => {
      const numberOfTeams = document.querySelector('#numberOfTeams').value;
      const teamsPerMatch = document.querySelector('#teamsPerMatch').value;
      onStart(numberOfTeams, teamsPerMatch);
    });
  }

  startTournament() {
    this.clearError();
    this.winnerDescription.style.visibility = 'hidden';
    this.dashboard.style.display = 'none';
    this.startButton.disabled = true;
  }

  endTournament(name) {
    document.querySelector('#winner').innerHTML = name;
    this.winnerDescription.style.visibility = 'visible';
    this.startButton.disabled = false;
  }

  initDashBoard(roundCount) {
    this.dashboard.style.display = 'block';
    let roundIndicatorRawHtml = '';
    for (let i = 0; i < roundCount; i++) {
      roundIndicatorRawHtml += '<span class="round-indicator"></span>';
    }
    this.roundIndicatorArea.innerHTML = roundIndicatorRawHtml;
  }

  updateRounds(roundNumber) {
    // nth-child start with index 1
    const dom = document.querySelector(`.round-indicator:nth-child(${roundNumber + 1})`);
    dom.style.backgroundColor = 'skyblue';
  }

  displayError(errMsg) {
    this.errorText.style.display = 'block';
    this.errorText.innerHTML = errMsg;
    this.startButton.disabled = false;
  }

  clearError() {
    this.errorText.style.display = 'none';
  }
}
