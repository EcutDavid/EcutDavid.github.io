/* global ApiHelper, RoutineHelper */
class TournamentController {
  constructor(eventHandleDic) {
    const {
      onRoundChnage,
      onTournamentCreated,
      onError,
      onStartTournament,
      onTournamentFinished
    } = eventHandleDic || {};
    // It will pass the number of last round to  this method when invoking
    this.onRoundChnage = onRoundChnage || (() => {});
    this.onError = onError || (() => {});
    this.onTournamentCreated = onTournamentCreated || (() => {});
    this.onTournamentFinished = onTournamentFinished || (() => {});
    this.onStartTournament = onStartTournament || (() => {});

    this.teamDictionary = {};
    this.matchUps = [];
    this.tournamentId = undefined;
  }

  startTournament(numberOfTeams, teamsPerMatch) {
    this.onStartTournament();
    this.createTournament(numberOfTeams, teamsPerMatch)
      .then(this.queryTeamDictionary.bind(this))
      .then(() => this.startNewRound(teamsPerMatch))
      .catch(reason => this.onError(reason));
  }

  createTournament(numberOfTeams, teamsPerMatch) {
    return new Promise((resolve, reject) => {
      ApiHelper.createTournament(numberOfTeams, teamsPerMatch)
        .then(({matchUps, tournamentId}) => {
          // Sort the matchUps for making "match" field in ascending order
          this.matchUps = matchUps.sort((a, b) => a.match > b.match ? 1 : -1);
          this.tournamentId = tournamentId;
          const roundCount = RoutineHelper.calcRoundCount(numberOfTeams, teamsPerMatch);
          this.onTournamentCreated(roundCount);
          resolve();
        }
      ).catch(errObj => reject(errObj));
    });
  }

  queryTeamDictionary() {
    return new Promise((resolve, reject) => {
      const queryTeamPromises = this.matchUps.reduce((acc, {teamIds}) => {
        return acc.concat(teamIds);
      }, []).map(d => ApiHelper.queryTeam(this.tournamentId, d));

      // Only query the data for team once since their score won't change
      Promise.all(queryTeamPromises).then(values => {
        values.forEach(d => this.teamDictionary[d.teamId] = d);
        resolve();
      }).catch(errObj => reject(errObj));
    });
  }

  startNewRound(teamsPerMatch, currentRound = 0, currentMatchList) {
    if (!currentMatchList)
      currentMatchList = this.matchUps.map(d => d.teamIds.sort());

    const queryMatchPromises = currentMatchList.map((_, i) => {
      return ApiHelper.queryMatch(this.tournamentId, currentRound, i);
    });

    Promise.all(queryMatchPromises).then(values => {
      const queryWinnerPromises = values.map((d, i) => {
        const teamScores = currentMatchList[i].map(d => this.teamDictionary[d].score);
        return ApiHelper.queryWinner(this.tournamentId, teamScores, d.score);
      });
      Promise.all(queryWinnerPromises).then(values => {
        const matchCount = values.length;
        const winnerScoreList = values.map(d => d.score);

        // This is the last round, let's relax and find out who is the winner
        if (matchCount === 1) {
          const winnerId = RoutineHelper.findMatchWinnerIdList(this.teamDictionary, winnerScoreList, currentMatchList)[0];
          this.onRoundChnage(currentRound);
          this.onTournamentFinished(this.teamDictionary[winnerId].name);
        } else {
          const winnerIdList = RoutineHelper.findMatchWinnerIdList(
            this.teamDictionary,
            winnerScoreList,
            currentMatchList
          );
          currentMatchList = [];
          for (let i = 0; i < matchCount / teamsPerMatch; i++)
            currentMatchList.push(winnerIdList.splice(0, teamsPerMatch));

          this.onRoundChnage(currentRound);
          currentRound++;
          this.startNewRound(teamsPerMatch, currentRound, currentMatchList);
        }
      }).catch(reason => this.onError(reason));
    }).catch(reason => this.onError(reason));
  }
}
